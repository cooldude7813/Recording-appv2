# Double Tap Recorder

Android voice recorder designed around a Home-screen double-tap shortcut.

## What this version adds
- Double-tap the Home screen to toggle recording when the accessibility service is enabled.
- Large Start/Stop button inside the app, so there is always a direct way to stop recording.
- Recordings are saved as M4A in the shared `Music/Double Tap Recorder` folder on Android 10+.
- Recording list with Play, Share, and Delete.
- Cleaner recorder layout and a custom microphone/tap launcher icon.
- Foreground microphone notification while recording.

## Important Android behavior
The Home-screen shortcut uses Android AccessibilityService gesture detection. Android requires the service to request touch exploration to receive the standard double-tap gesture callback. This means the phone may show accessibility-related behavior while the service is enabled. The shortcut is intentionally limited to the Home screen by checking the active launcher window.

The screen being completely off/asleep cannot be treated as an ordinary touchscreen double-tap by this app. The in-app Stop button and notification provide a reliable way to stop a recording.

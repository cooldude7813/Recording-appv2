plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.example.tripletaprecorder"; compileSdk = 35
    defaultConfig { applicationId = "com.example.tripletaprecorder"; minSdk = 29; targetSdk = 35; versionCode = 2; versionName = "2.0" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

package com.example.tripletaprecorder

import android.accessibilityservice.AccessibilityGestureEvent
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class HomeGestureService : AccessibilityService() {
    private var homeVisible = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.notificationTimeout = 50
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        if (Build.VERSION.SDK_INT >= 30) {
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE
        }
        setServiceInfo(info)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        homeVisible = pkg == "com.android.launcher3" || pkg.contains("launcher") || pkg.contains("motorola")
    }

    override fun onGesture(gestureEvent: AccessibilityGestureEvent): Boolean {
        if (gestureEvent.gestureId == AccessibilityService.GESTURE_DOUBLE_TAP && homeVisible) {
            val intent = Intent(this, RecordingService::class.java).setAction(RecordingService.ACTION_TOGGLE)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            return true
        }
        return super.onGesture(gestureEvent)
    }

    override fun onInterrupt() {}
}

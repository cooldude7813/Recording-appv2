package com.example.tripletaprecorder

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var recordButton: Button
    private lateinit var recordingsList: LinearLayout
    private var player: MediaPlayer? = null

    private val prefs by lazy { getSharedPreferences(RecordingService.PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshRecordings()
    }

    override fun onResume() {
        super.onResume()
        refreshState()
        refreshRecordings()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(Color.rgb(248, 247, 252))
        }

        val title = TextView(this).apply {
            text = "Double Tap Recorder"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(30, 28, 36))
        }
        val subtitle = TextView(this).apply {
            text = "Quick voice recordings, saved automatically."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(18))
        }
        root.addView(title)
        root.addView(subtitle)

        statusText = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        recordButton = Button(this).apply {
            textSize = 18f
            setAllCaps(false)
            setOnClickListener { toggleRecording() }
        }
        root.addView(recordButton, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(14) })

        val shortcut = TextView(this).apply {
            text = "DOUBLE-TAP\nDouble-tap the Home screen to start or stop."
            textSize = 16f
            setTextColor(Color.rgb(45, 43, 52))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(shortcut, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val access = Button(this).apply {
            text = "Enable Home-screen double tap"
            setAllCaps(false)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(access, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val location = TextView(this).apply {
            text = "Saves to: Music / Double Tap Recorder"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(dp(4), 0, 0, dp(10))
        }
        root.addView(location)

        val recordingsTitle = TextView(this).apply {
            text = "Recordings"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(30, 28, 36))
        }
        root.addView(recordingsTitle)

        val scroll = ScrollView(this)
        recordingsList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(recordingsList)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val mic = Button(this).apply {
            text = "Allow microphone"
            setAllCaps(false)
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10) }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        setContentView(root)
        refreshState()
    }

    private fun toggleRecording() {
        val action = if (prefs.getBoolean(RecordingService.KEY_RECORDING, false)) RecordingService.ACTION_STOP else RecordingService.ACTION_START
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val intent = Intent(this, RecordingService::class.java).setAction(action)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        window.decorView.postDelayed({ refreshState() }, 400)
    }

    private fun refreshState() {
        val recording = prefs.getBoolean(RecordingService.KEY_RECORDING, false)
        if (recording) {
            statusText.text = "●  RECORDING"
            statusText.setTextColor(Color.rgb(190, 30, 45))
            recordButton.text = "Stop recording"
        } else {
            statusText.text = "●  Ready"
            statusText.setTextColor(Color.rgb(45, 120, 70))
            recordButton.text = "Start recording"
        }
    }

    private fun refreshRecordings() {
        if (!::recordingsList.isInitialized) return
        recordingsList.removeAllViews()
        val recordings = queryRecordings()
        if (recordings.isEmpty()) {
            recordingsList.addView(TextView(this).apply {
                text = "No recordings yet."
                textSize = 16f
                setTextColor(Color.GRAY)
                setPadding(dp(8), dp(16), dp(8), dp(16))
            })
            return
        }
        recordings.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(10), dp(12))
                setBackgroundColor(Color.WHITE)
            }
            val name = TextView(this).apply {
                text = item.name
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(35, 33, 40))
            }
            val date = TextView(this).apply {
                text = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(item.date * 1000))
                textSize = 13f
                setTextColor(Color.GRAY)
            }
            val buttons = LinearLayout(this).apply { gravity = Gravity.END }
            val play = Button(this).apply {
                text = "Play"
                setAllCaps(false)
                setOnClickListener { play(item.uri) }
            }
            val share = Button(this).apply {
                text = "Share"
                setAllCaps(false)
                setOnClickListener { share(item.uri, item.name) }
            }
            val delete = Button(this).apply {
                text = "Delete"
                setAllCaps(false)
                setOnClickListener {
                    contentResolver.delete(item.uri, null, null)
                    refreshRecordings()
                }
            }
            buttons.addView(play); buttons.addView(share); buttons.addView(delete)
            row.addView(name); row.addView(date); row.addView(buttons)
            recordingsList.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private data class RecordingItem(val uri: Uri, val name: String, val date: Long)

    private fun queryRecordings(): List<RecordingItem> {
        val result = mutableListOf<RecordingItem>()
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATE_ADDED)
        val selection = if (Build.VERSION.SDK_INT >= 29) "${MediaStore.Audio.Media.RELATIVE_PATH}=?" else null
        val args = if (Build.VERSION.SDK_INT >= 29) arrayOf("Music/Double Tap Recorder/") else null
        contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, args, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (c.moveToNext()) {
                result.add(RecordingItem(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)), c.getString(nameCol), c.getLong(dateCol)))
            }
        }
        return result
    }

    private fun play(uri: Uri) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, uri)
            prepare()
            start()
            setOnCompletionListener { release(); player = null }
        }
    }

    private fun share(uri: Uri, name: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share recording"))
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

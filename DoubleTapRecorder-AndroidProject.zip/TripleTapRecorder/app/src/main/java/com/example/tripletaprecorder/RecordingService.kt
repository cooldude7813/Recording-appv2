package com.example.tripletaprecorder

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import java.io.File

class RecordingService : Service() {
    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        const val ACTION_TOGGLE = "TOGGLE"
        const val PREFS = "recorder_state"
        const val KEY_RECORDING = "recording"
    }

    private var recorder: MediaRecorder? = null
    private var outputUri: Uri? = null
    private var legacyOutput: File? = null
    private var outputPfd: android.os.ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRecording()
            ACTION_TOGGLE -> if (recorder == null) startRecording() else stopRecording()
            else -> if (recorder == null) startRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        val channel = "recording"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "Recording", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channel)
                .setContentTitle("Double Tap Recorder")
                .setContentText("Recording audio — tap Stop in the app to finish")
                .setSmallIcon(R.drawable.ic_mic)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Double Tap Recorder")
                .setContentText("Recording audio")
                .setSmallIcon(R.drawable.ic_mic)
                .setOngoing(true)
                .build()
        }
        startForeground(1, notification)

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "Recording_${System.currentTimeMillis()}.m4a")
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Double Tap Recorder")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                outputUri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create recording file")
            } else {
                val dir = getExternalFilesDir("Recordings") ?: filesDir
                dir.mkdirs()
                legacyOutput = File(dir, "Recording_${System.currentTimeMillis()}.m4a")
            }

            outputPfd = outputUri?.let { contentResolver.openFileDescriptor(it, "w") }
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                if (outputPfd != null) setOutputFile(outputPfd!!.fileDescriptor) else setOutputFile(legacyOutput!!.absolutePath)
                prepare()
                start()
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, true).apply()
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            outputUri?.let { contentResolver.delete(it, null, null) }
            outputUri = null
            legacyOutput = null
            outputPfd?.close()
            outputPfd = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopRecording() {
        val currentRecorder = recorder ?: run {
            stopSelf()
            return
        }
        try {
            currentRecorder.stop()
        } catch (_: Exception) {
            outputUri?.let { contentResolver.delete(it, null, null) }
            legacyOutput?.delete()
        }
        currentRecorder.release()
        recorder = null

        if (Build.VERSION.SDK_INT >= 29) {
            outputUri?.let { uri ->
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.IS_PENDING, 0)
                }
                contentResolver.update(uri, values, null, null)
            }
        }

        outputUri = null
        legacyOutput = null
        outputPfd?.close()
        outputPfd = null
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RECORDING, false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
